import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["EH4"],
  pin2: ["EH3"],
  pin3: ["EH1"],
  pin4: ["EH2"],
  pin5: ["A5", "CC1"],
  pin6: ["B5", "CC2"],
  pin7: ["A9", "VBUS1"],
  pin8: ["B9", "VBUS2"],
  pin9: ["A12", "GND1"],
  pin10: ["B12", "GND2"]
} as const

export const TYPE_C_6PIN = (props: ChipProps<typeof pinLabels>) => {
  return (
    <chip
      pinLabels={pinLabels}
      supplierPartNumbers={{
  "jlcpcb": [
    "C7507406"
  ]
}}
      manufacturerPartNumber="TYPE-C 6PIN"
      footprint={<footprint>
        <platedhole  portHints={["pin3"]} pcbX="4.319905mm" pcbY="-2.4159273mm" holeWidth="0.5000244mm" holeHeight="1.200023mm" outerWidth="0.999998mm" outerHeight="1.6999966mm" shape="pill" />
<platedhole  portHints={["pin4"]} pcbX="-4.319905mm" pcbY="-2.4159273mm" holeWidth="0.5000244mm" holeHeight="1.200023mm" outerWidth="0.999998mm" outerHeight="1.6999966mm" shape="pill" />
<platedhole  portHints={["pin2"]} pcbX="4.319905mm" pcbY="1.3841667mm" holeWidth="0.5000244mm" holeHeight="1.200023mm" outerWidth="0.999998mm" outerHeight="1.6999966mm" shape="pill" />
<platedhole  portHints={["pin1"]} pcbX="-4.319905mm" pcbY="1.3841667mm" holeWidth="0.5000244mm" holeHeight="1.200023mm" outerWidth="0.999998mm" outerHeight="1.6999966mm" shape="pill" />
<smtpad portHints={["pin5"]} pcbX="-0.499999mm" pcbY="1.7618647mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<smtpad portHints={["pin6"]} pcbX="0.499999mm" pcbY="1.7618647mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<smtpad portHints={["pin7"]} pcbX="1.520063mm" pcbY="1.7633887mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<smtpad portHints={["pin8"]} pcbX="-1.519809mm" pcbY="1.7659287mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<smtpad portHints={["pin9"]} pcbX="2.750185mm" pcbY="1.7641507mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<smtpad portHints={["pin10"]} pcbX="-2.749931mm" pcbY="1.7641507mm" width="0.7999984mm" height="1.3999972mm" shape="rect" />
<silkscreenpath route={[{"x":-4.470044400000006,"y":-1.350371900000141},{"x":-4.470044400000006,"y":0.31861130000004323}]} />
<silkscreenpath route={[{"x":-4.470044400000006,"y":-5.0162522999999055},{"x":-4.470044400000006,"y":-3.4813811000000214}]} />
<silkscreenpath route={[{"x":4.469942800000126,"y":-1.350371900000141},{"x":4.469942800000126,"y":0.31861130000004323}]} />
<silkscreenpath route={[{"x":4.469942800000126,"y":-5.0162522999999055},{"x":4.469942800000126,"y":-3.4813811000000214}]} />
<silkscreenpath route={[{"x":4.469942800000126,"y":-5.0162522999999055},{"x":-4.470044400000006,"y":-5.0162522999999055}]} />
<courtyardoutline outline={[{"x":-4.722304999999892,"y":2.7240807000000586},{"x":4.718494999999962,"y":2.7240807000000586},{"x":4.718494999999962,"y":-5.268919299999993},{"x":-4.722304999999892,"y":-5.268919299999993},{"x":-4.722304999999892,"y":2.7240807000000586}]} />
      </footprint>}
      cadModel={{
        objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C7507406.obj?uuid=d0cb5810bd1c49468b0a202e861a48e0",
        stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C7507406.step?uuid=d0cb5810bd1c49468b0a202e861a48e0",
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 2.725691, y: 6.300192899999986, z: -4.004012 },
      }}
      {...props}
    />
  )
}

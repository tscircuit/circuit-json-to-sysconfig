import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["C"],
  pin2: ["A"]
} as const

export const ESD5Z5_0T1G = (props: ChipProps<typeof pinLabels>) => {
  return (
    <chip
      pinLabels={pinLabels}
      symbol={
        <symbol>
          <port name="pin2" pinNumber={2} aliases={["A"]} direction="right" schX={0.4} schY={0} schStemLength={0.3} />
          <port name="pin1" pinNumber={1} aliases={["C"]} direction="left" schX={-0.4} schY={0} schStemLength={0.3} />
          <schematicpath svgPath="M 0.1 0.12 L -0.1 0 L 0.1 -0.14 Z" strokeColor="#880000" isFilled fillColor="#880000" />
          <schematicpath points={[{"x":-0.14,"y":-0.16},{"x":-0.1,"y":-0.16},{"x":-0.1,"y":0.14},{"x":-0.04,"y":0.14}]} strokeColor="#880000" />
          <schematicrect schX={0} schY={0} width={0.8} height={0.4} color="#880000" />
        </symbol>
      }
      supplierPartNumbers={{
  "jlcpcb": [
    "C82044"
  ]
}}
      manufacturerPartNumber="ESD5Z5.0T1G"
      footprint={<footprint>
        <smtpad portHints={["pin1"]} points={[{x: "-1.016mm", y: "0.2463038mm"}, {x: "-0.4064mm", y: "0.2463038mm"}, {x: "-0.4064mm", y: "-0.2362962mm"}, {x: "-1.016mm", y: "-0.2362962mm"}]} shape="polygon" />
<smtpad portHints={["pin2"]} points={[{x: "0.4064mm", y: "0.2362962mm"}, {x: "1.016mm", y: "0.2362962mm"}, {x: "1.016mm", y: "-0.2463038mm"}, {x: "0.4064mm", y: "-0.2463038mm"}]} shape="polygon" />
<silkscreenpath route={[{"x":0.6602730000000037,"y":-0.3261614000000037},{"x":0.6602730000000037,"y":-0.43185080000000653},{"x":-0.6605270000000019,"y":-0.43185080000000653},{"x":-0.6603999999999814,"y":-0.43180000000000973}]} />
<silkscreenpath route={[{"x":-0.6603999999999814,"y":0.4317999999999955},{"x":-0.6603999999999814,"y":0.4317999999999955},{"x":0.6604000000000099,"y":0.4317999999999955},{"x":0.6604000000000099,"y":0.3301999999999907}]} />
<courtyardoutline outline={[{"x":-1.2661269999999973,"y":0.736638599999992},{"x":1.2658730000000133,"y":0.736638599999992},{"x":1.2658730000000133,"y":-0.728561400000018},{"x":-1.2661269999999973,"y":-0.728561400000018},{"x":-1.2661269999999973,"y":0.736638599999992}]} />
      </footprint>}
      cadModel={{
        objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C82044.obj?uuid=84cf6c2b182949329e473e9158b1fb00",
        stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C82044.step?uuid=84cf6c2b182949329e473e9158b1fb00",
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 0, y: -0.0040386000000012245, z: 0 },
      }}
      {...props}
    />
  )
}

import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["pin1", "XIN"],
  pin2: ["GND1"],
  pin3: ["pin3", "XOUT"],
  pin4: ["GND2"]
} as const

export const ABM11W_48_0000MHZ_7_B1U_T3 = (props: ChipProps<typeof pinLabels>) => {
  return (
    <chip
      pinLabels={pinLabels}
      symbol={
        <symbol>
          <port name="pin1" pinNumber={1} aliases={["1"]} direction="left" schX={-0.6} schY={-0.2} schStemLength={0.2} />
          <port name="pin3" pinNumber={3} aliases={["3"]} direction="right" schX={0.6} schY={0.2} schStemLength={0.2} />
          <port name="pin4" pinNumber={4} aliases={["GND2","GND"]} direction="left" schX={-0.6} schY={0.2} schStemLength={0.2} />
          <port name="pin2" pinNumber={2} aliases={["GND1","GND"]} direction="right" schX={0.6} schY={-0.2} schStemLength={0.2} />
          <schematicrect schX={0} schY={0} width={1.4} height={0.8} color="#880000" />
          <schematiccircle center={{ x: -0.3, y: -0.3 }} radius={0.03} color="#880000" isFilled fillColor="#880000" />
          <schematicpath points={[{"x":-0.1,"y":-0.14},{"x":-0.1,"y":0.14}]} strokeColor="#881100" />
          <schematicpath points={[{"x":0.1,"y":-0.14},{"x":0.1,"y":0.14}]} strokeColor="#881100" />
          <schematicpath points={[{"x":-0.4,"y":-0.2},{"x":-0.2,"y":-0.2},{"x":-0.2,"y":0},{"x":-0.1,"y":0}]} strokeColor="#880000" />
          <schematicpath points={[{"x":0.4,"y":0.2},{"x":0.2,"y":0.2},{"x":0.2,"y":0},{"x":0.1,"y":0}]} strokeColor="#880000" />
          <schematicrect schX={0} schY={0} width={0.08} height={0.28} color="#880000" />
        </symbol>
      }
      supplierPartNumbers={{
  "jlcpcb": [
    "C1985532"
  ]
}}
      manufacturerPartNumber="ABM11W-48.0000MHZ-7-B1U-T3"
      footprint={<footprint>
        <smtpad portHints={["pin2"]} pcbX="0.700024mm" pcbY="-0.54991mm" width="0.8999982mm" height="0.7999984mm" shape="rect" />
<smtpad portHints={["pin3"]} pcbX="0.700024mm" pcbY="0.54991mm" width="0.8999982mm" height="0.7999984mm" shape="rect" />
<smtpad portHints={["pin4"]} pcbX="-0.700024mm" pcbY="0.54991mm" width="0.8999982mm" height="0.7999984mm" shape="rect" />
<smtpad portHints={["pin1"]} pcbX="-0.700024mm" pcbY="-0.54991mm" width="0.8999982mm" height="0.7999984mm" shape="rect" />
<silkscreenpath route={[{"x":-1.6499840000001313,"y":-0.15001239999992322},{"x":-1.6499840000001313,"y":-1.4500097999999753},{"x":-0.24998679999998785,"y":-1.4500097999999753}]} />
<courtyardoutline outline={[{"x":-1.9010000000000673,"y":1.393000000000029},{"x":1.5962000000000671,"y":1.393000000000029},{"x":1.5962000000000671,"y":-1.6977999999999156},{"x":-1.9010000000000673,"y":-1.6977999999999156},{"x":-1.9010000000000673,"y":1.393000000000029}]} />
      </footprint>}
      cadModel={{
        objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C1985532.obj?uuid=51ae9b24ba7a408881f7752b57b66e45",
        stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C1985532.step?uuid=51ae9b24ba7a408881f7752b57b66e45",
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 0, y: 0.000012699999956566899, z: -0.01 },
      }}
      {...props}
    />
  )
}

import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["pin1", "VDD"],
  pin2: ["pin2", "GND"],
  pin3: ["pin3", "BUS_CLK"],
  pin4: ["pin4", "BUS_DATA"],
  pin5: ["pin5", "DISP_CS"],
  pin6: ["pin6", "DISP_DC"],
  pin7: ["pin7", "DISP_RST"],
  pin8: ["pin8", "MOUNT1"],
  pin9: ["pin9", "MOUNT2"]
} as const

export const BM07B_SRSS_TB_LF__SN_ = (props: ChipProps<typeof pinLabels>) => {
  return (
    <chip
      pinLabels={pinLabels}
      supplierPartNumbers={{
  "jlcpcb": [
    "C160393"
  ]
}}
      manufacturerPartNumber="BM07B-SRSS-TB(LF)(SN)"
      footprint={<footprint>
        <smtpad portHints={["pin1"]} pcbX="2.999994mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin2"]} pcbX="1.999996mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin3"]} pcbX="0.999998mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin4"]} pcbX="0mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin5"]} pcbX="-0.999998mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin6"]} pcbX="-1.999996mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin7"]} pcbX="-2.999994mm" pcbY="1.3250037mm" width="0.5999988mm" height="1.5500096mm" shape="rect" />
<smtpad portHints={["pin8"]} pcbX="-4.299966mm" pcbY="-1.2000103mm" width="1.1999976mm" height="1.7999964mm" shape="rect" />
<smtpad portHints={["pin9"]} pcbX="4.299966mm" pcbY="-1.2000103mm" width="1.1999976mm" height="1.7999964mm" shape="rect" />
<silkscreenpath route={[{"x":4.5000164000000495,"y":1.0249789000000646},{"x":4.5000164000000495,"y":-0.06882129999996778}]} />
<silkscreenpath route={[{"x":3.531133399999817,"y":1.0249789000000646},{"x":4.5000164000000495,"y":1.0249789000000646}]} />
<silkscreenpath route={[{"x":-4.5000164000000495,"y":1.0249789000000646},{"x":-3.5311334000000443,"y":1.0249789000000646}]} />
<silkscreenpath route={[{"x":3.4999930000000177,"y":-1.874989899999946},{"x":-3.4999930000001314,"y":-1.874989899999946}]} />
<silkscreenpath route={[{"x":-4.5000164000000495,"y":1.0249789000000646},{"x":-4.5000164000000495,"y":-0.06882129999996778}]} />
<silkscreenpath route={[{"x":3.837000200000034,"y":1.6224884999999176},{"x":3.832672779938548,"y":1.5896184812720549},{"x":3.819985426280482,"y":1.5589884999999413},{"x":3.7998027612106853,"y":1.5326859387893137},{"x":3.773500199999944,"y":1.5125032737194033},{"x":3.742870218727944,"y":1.4998159200612236},{"x":3.7100001999999677,"y":1.495488499999965},{"x":3.677130181271991,"y":1.4998159200612236},{"x":3.6465001999999913,"y":1.5125032737194033},{"x":3.62019763878925,"y":1.5326859387893137},{"x":3.6000149737193397,"y":1.5589884999999413},{"x":3.58732762006116,"y":1.5896184812720549},{"x":3.583000200000015,"y":1.6224884999999176},{"x":3.58732762006116,"y":1.6553585187280078},{"x":3.6000149737193397,"y":1.6859885000001213},{"x":3.62019763878925,"y":1.712291061210749},{"x":3.6465001999999913,"y":1.7324737262805456},{"x":3.677130181271991,"y":1.7451610799387254},{"x":3.7100001999999677,"y":1.7494885000000977},{"x":3.742870218727944,"y":1.7451610799387254},{"x":3.773500199999944,"y":1.7324737262805456},{"x":3.7998027612106853,"y":1.712291061210749},{"x":3.819985426280482,"y":1.6859885000001213},{"x":3.832672779938548,"y":1.6553585187280078},{"x":3.837000200000034,"y":1.6224884999999176}]} />
<courtyardoutline outline={[{"x":-5.152200000000107,"y":2.342083700000103},{"x":5.15219999999988,"y":2.342083700000103},{"x":5.15219999999988,"y":-2.348916299999928},{"x":-5.152200000000107,"y":-2.348916299999928},{"x":-5.152200000000107,"y":2.342083700000103}]} />
      </footprint>}
      cadModel={{
        objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C160393.obj?uuid=57f411570dd7482b9205d313fa2d2714",
        stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C160393.step?uuid=57f411570dd7482b9205d313fa2d2714",
        pcbRotationOffset: 180,
        modelOriginPosition: { x: 3, y: -0.34546990000009825, z: -0.01 },
      }}
      {...props}
    />
  )
}

import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["ANT"],
  pin2: ["VDDR1"],
  pin3: ["DIO8"],
  pin4: ["DIO11"],
  pin5: ["DIO12"],
  pin6: ["DIO13"],
  pin7: ["DIO16_SWDIO"],
  pin8: ["DIO17_SWDCK"],
  pin9: ["DIO20_A11"],
  pin10: ["DIO21_A10"],
  pin11: ["VDDS1"],
  pin12: ["DIO24_A7"],
  pin13: ["RSTN"],
  pin14: ["DIO3_X32P"],
  pin15: ["DIO4_X32N"],
  pin16: ["VDDD"],
  pin17: ["DCDC"],
  pin18: ["VDDS2"],
  pin19: ["DIO6_A1"],
  pin20: ["VDDR2"],
  pin21: ["X48P"],
  pin22: ["X48N"],
  pin23: ["GND"],
  pin24: ["VDDS3"],
  pin25: ["EP"]
} as const

export const CC2340R52E0RGER = (props: ChipProps<typeof pinLabels>) => {
  return (
    <chip
      pinLabels={pinLabels}
      supplierPartNumbers={{
  "jlcpcb": [
    "C20416850"
  ]
}}
      manufacturerPartNumber="CC2340R52E0RGER"
      footprint={<footprint>
        <smtpad portHints={["pin1"]} pcbX="-1.89992mm" pcbY="1.250061mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin2"]} pcbX="-1.89992mm" pcbY="0.750189mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin3"]} pcbX="-1.89992mm" pcbY="0.250063mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin4"]} pcbX="-1.89992mm" pcbY="-0.249809mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin5"]} pcbX="-1.89992mm" pcbY="-0.749935mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin6"]} pcbX="-1.89992mm" pcbY="-1.249807mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin7"]} pcbX="-1.250188mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin8"]} pcbX="-0.750316mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin9"]} pcbX="-0.25019mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin10"]} pcbX="0.249682mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin11"]} pcbX="0.749808mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin12"]} pcbX="1.24968mm" pcbY="-1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin13"]} pcbX="1.89992mm" pcbY="-1.250061mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin14"]} pcbX="1.89992mm" pcbY="-0.749935mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin15"]} pcbX="1.89992mm" pcbY="-0.250063mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin16"]} pcbX="1.89992mm" pcbY="0.250063mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin17"]} pcbX="1.89992mm" pcbY="0.749935mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin18"]} pcbX="1.89992mm" pcbY="1.250061mm" width="0.5999988mm" height="0.2500122mm" shape="rect" />
<smtpad portHints={["pin19"]} pcbX="1.24968mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin20"]} pcbX="0.749808mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin21"]} pcbX="0.249682mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin22"]} pcbX="-0.25019mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin23"]} pcbX="-0.750316mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin24"]} pcbX="-1.250188mm" pcbY="1.900047mm" width="0.2500122mm" height="0.5999988mm" shape="rect" />
<smtpad portHints={["pin25"]} pcbX="0mm" pcbY="-0.000127mm" width="2.4500078mm" height="2.4500078mm" shape="rect" />
<silkscreenpath route={[{"x":-2.1044915999999603,"y":1.7001743999999235},{"x":-2.1044915999999603,"y":2.100148200000035},{"x":-1.7001743999999235,"y":2.1000212000000147}]} />
<silkscreenpath route={[{"x":-2.1001990000000887,"y":-1.6998696000000564},{"x":-2.1001990000000887,"y":-2.0999704000000747},{"x":-1.7001743999999235,"y":-2.0999704000000747}]} />
<silkscreenpath route={[{"x":2.0997926000000007,"y":-1.5999713999999585},{"x":2.0997926000000007,"y":-2.0999704000000747},{"x":1.6998188000001164,"y":-2.0999704000000747}]} />
<silkscreenpath route={[{"x":1.6954753999999639,"y":2.100148200000035},{"x":2.095449199999962,"y":2.100148200000035},{"x":2.095449199999962,"y":1.7001743999999235}]} />
<silkscreenpath route={[{"x":-2.4132540000000517,"y":1.9051269999999931},{"x":-2.4175814200613104,"y":1.872256981271903},{"x":-2.43026877371949,"y":1.8416270000000168},{"x":-2.450451438789287,"y":1.8153244387892755},{"x":-2.476754000000028,"y":1.7951417737194788},{"x":-2.507383981272028,"y":1.782454420061299},{"x":-2.5402540000000045,"y":1.7781269999999267},{"x":-2.5731240187280946,"y":1.782454420061299},{"x":-2.603753999999981,"y":1.7951417737194788},{"x":-2.6300565612106084,"y":1.8153244387892755},{"x":-2.6502392262806325,"y":1.8416270000000168},{"x":-2.6629265799386985,"y":1.872256981271903},{"x":-2.667253999999957,"y":1.9051269999999931},{"x":-2.6629265799386985,"y":1.9379970187279696},{"x":-2.6502392262806325,"y":1.9686269999999695},{"x":-2.6300565612106084,"y":1.9949295612107107},{"x":-2.603753999999981,"y":2.015112226280621},{"x":-2.5731240187280946,"y":2.027799579938687},{"x":-2.5402540000000045,"y":2.032126999999946},{"x":-2.507383981272028,"y":2.027799579938687},{"x":-2.476754000000028,"y":2.015112226280621},{"x":-2.450451438789287,"y":1.9949295612107107},{"x":-2.43026877371949,"y":1.9686269999999695},{"x":-2.4175814200613104,"y":1.9379970187279696},{"x":-2.4132540000000517,"y":1.9051269999999931}]} />
<courtyardoutline outline={[{x:-2.45,y:-2.45},{x:2.45,y:-2.45},{x:2.45,y:2.45},{x:-2.45,y:2.45},{x:-2.45,y:-2.45}]} />
      </footprint>}
      cadModel={{
        objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C20416850.obj?uuid=d7837941ee5a48928cbbb5a65ba7a879",
        stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C20416850.step?uuid=d7837941ee5a48928cbbb5a65ba7a879",
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 0, y: 0.000025400000026820635, z: 0 },
      }}
      {...props}
    />
  )
}
